/** Zero-padded 32-byte codec for `Bytes<32>` contract values (names, etc.). */
export function encodeBytes32(input: string): Uint8Array {
  const bytes = new Uint8Array(32);
  const encoded = new TextEncoder().encode(input);
  if (encoded.length > 32) {
    throw new Error(`Value exceeds 32 bytes: '${input}' (${encoded.length} bytes)`);
  }
  bytes.set(encoded);
  return bytes;
}

export function decodeBytes32(bytes: Uint8Array): string {
  const firstZero = bytes.findIndex((b) => b === 0);
  const end = firstZero === -1 ? bytes.length : firstZero;
  return new TextDecoder().decode(bytes.slice(0, end));
}

/** Short hex preview like `0x1a2b…9c` for UI display. */
export function shortHex(bytes: Uint8Array, keep = 4): string {
  const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
  return `0x${hex.slice(0, keep)}…${hex.slice(-keep)}`;
}

/** Fixed 32-byte commitment codec — used for wallet secret keys. */
export function normalizeSecretKey(sk: Uint8Array): Uint8Array {
  const bytes = new Uint8Array(32);
  bytes.set(sk.slice(0, 32));
  return bytes;
}
